package com.example.preferencesapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.preferencesapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var setType = 0
    private var elementType = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Settings button opens the edit page
        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, PreferencesActivity::class.java))
        }

        // Load saved build when app opens
        loadSavedBuild()
        updateHomeScreen()
    }

    override fun onResume() {
        super.onResume()
        // Refresh the home screen in case the user saved a new build
        loadSavedBuild()
        updateHomeScreen()
    }

    private fun loadSavedBuild() {
        val prefs = getSharedPreferences("build_prefs", MODE_PRIVATE)
        setType = prefs.getInt("setType", 0)
        elementType = prefs.getInt("elementType", 0)
    }

    private fun updateHomeScreen() {
        // Set image on the left / set display
        when (setType) {
            0 -> binding.setsImage.setImageResource(R.drawable.body_selected)
            1 -> binding.setsImage.setImageResource(R.drawable.mind_selected)
            2 -> binding.setsImage.setImageResource(R.drawable.soul_selected)
        }

        // Element image
        when (elementType) {
            0 -> binding.elementImage.setImageResource(R.drawable.element_water)
            1 -> binding.elementImage.setImageResource(R.drawable.element_earth)
            2 -> binding.elementImage.setImageResource(R.drawable.element_fire)
            3 -> binding.elementImage.setImageResource(R.drawable.element_air)
        }

        // Combined image + text
        when (setType) {
            0 -> { // Body
                when (elementType) {
                    0 -> {
                        binding.combinedImage.setImageResource(R.drawable.body_water)
                        binding.textTitle.text = "Liquid State"
                        binding.textDesc.text = "Your body excretes water, allowing for versatile forms."
                    }
                    1 -> {
                        binding.combinedImage.setImageResource(R.drawable.body_earth)
                        binding.textTitle.text = "Walking Fortress"
                        binding.textDesc.text = "Your body develops hard materials and defensive forms."
                    }
                    2 -> {
                        binding.combinedImage.setImageResource(R.drawable.body_fire)
                        binding.textTitle.text = "Intense Ignition"
                        binding.textDesc.text = "Your body sustains fire and can coat itself or shoot flames."
                    }
                    3 -> {
                        binding.combinedImage.setImageResource(R.drawable.body_air)
                        binding.textTitle.text = "Flowing Breath"
                        binding.textDesc.text = "Your body circulates air for gusts, movement, and flight."
                    }
                }
            }

            1 -> { // Mind
                when (elementType) {
                    0 -> {
                        binding.combinedImage.setImageResource(R.drawable.mind_water)
                        binding.textTitle.text = "Imbued Flow"
                        binding.textDesc.text = "Channel the interpretation of liquids into similar objects."
                    }
                    1 -> {
                        binding.combinedImage.setImageResource(R.drawable.mind_earth)
                        binding.textTitle.text = "Imbued Stability"
                        binding.textDesc.text = "Channel the interpretation of earth into similar objects."
                    }
                    2 -> {
                        binding.combinedImage.setImageResource(R.drawable.mind_fire)
                        binding.textTitle.text = "Imbued Sparks"
                        binding.textDesc.text = "Channel the interpretation of fire into explosive forms."
                    }
                    3 -> {
                        binding.combinedImage.setImageResource(R.drawable.mind_air)
                        binding.textTitle.text = "Imbued Breeze"
                        binding.textDesc.text = "Channel the interpretation of air into floaty or stormy forms."
                    }
                }
            }

            2 -> { // Soul
                when (elementType) {
                    0 -> {
                        binding.combinedImage.setImageResource(R.drawable.soul_water)
                        binding.textTitle.text = "Remote Geyser"
                        binding.textDesc.text = "Manipulate water from sources like a puddle or ocean."
                    }
                    1 -> {
                        binding.combinedImage.setImageResource(R.drawable.soul_earth)
                        binding.textTitle.text = "Linked Terraform"
                        binding.textDesc.text = "Manipulate earth from sources like ground or rock."
                    }
                    2 -> {
                        binding.combinedImage.setImageResource(R.drawable.soul_fire)
                        binding.textTitle.text = "Combined Combustion"
                        binding.textDesc.text = "Manipulate fire from sources like a candle or wildfire."
                    }
                    3 -> {
                        binding.combinedImage.setImageResource(R.drawable.soul_air)
                        binding.textTitle.text = "Mutual Gale"
                        binding.textDesc.text = "Manipulate air from sources like breeze or hurricane."
                    }
                }
            }
        }
    }
}