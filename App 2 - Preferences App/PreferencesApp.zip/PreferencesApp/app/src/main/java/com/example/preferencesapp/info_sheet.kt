package com.example.preferencesapp

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class InfoDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        return AlertDialog.Builder(requireContext())
            .setTitle("Creative Calculator by James")

            .setMessage(
                "This section is where you change your preferred build. Based on a personal story/lore.\n\n" +

                        "How to use:\n" +
                        "1. Select one of the sets (Outer buttons).\n" +
                        "2. Tap the center button to change element.\n" +
                        "3. Press save and go back home to view results.\n\n" +
                        "Different combinations give different results.\n\n"

            )

            .setPositiveButton("CLOSE") { dialog, _ ->
                dialog.dismiss()
            }

            .create()
    }
}