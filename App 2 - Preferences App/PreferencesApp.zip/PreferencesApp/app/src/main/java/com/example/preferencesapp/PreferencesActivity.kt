package com.example.preferencesapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.preferencesapp.databinding.PreferencesPageBinding

class PreferencesActivity : AppCompatActivity() {

    private lateinit var binding: PreferencesPageBinding

    private var elementType = 0 // 0-3
    private var setType = 0     // 0 = Body, 1 = Mind, 2 = Soul

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = PreferencesPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Load previously saved preferences so the screen opens on the last choice
        loadSavedPreferences()

        // Info modal button
        binding.infoButton.setOnClickListener {
            InfoDialog().show(supportFragmentManager, "info_sheet")
        }

        // Body
        binding.bodyButton.setOnClickListener {
            binding.textSet.text = "Body Set: Aura channels throughout the body, generating the element physically."
            setType = 0
            updateSelection()
        }

        // Mind
        binding.mindButton.setOnClickListener {
            binding.textSet.text = "Mind Set: Aura channels to an external object, imbuing it with the element and user's interpretation."
            setType = 1
            updateSelection()
        }

        // Soul
        binding.soulButton.setOnClickListener {
            binding.textSet.text = "Soul Set: Aura channels and connects with an external element, bridging a gap between the element and the user."
            setType = 2
            updateSelection()
        }

        // Element cycle button
        binding.elementButton.setOnClickListener {
            elementType = (elementType + 1) % 4
            updateElement()
        }

        // Save button
        binding.saveButton.setOnClickListener {
            savePreferences()
            finish() // go back to MainActivity
        }

        // Home button
        binding.homeButton.setOnClickListener {
            finish() // return to MainActivity without saving extra changes
        }

        updateSelection()
        updateElement()
    }

    private fun loadSavedPreferences() {
        val prefs = getSharedPreferences("build_prefs", MODE_PRIVATE)
        setType = prefs.getInt("setType", 0)
        elementType = prefs.getInt("elementType", 0)

        // Update the text when loading
        when (setType) {
            0 -> binding.textSet.text = "Body Set: Aura channels throughout the body, generating the element physically."
            1 -> binding.textSet.text = "Mind Set: Aura channels to an external object, imbuing it with the element and user's interpretation."
            2 -> binding.textSet.text = "Soul Set: Aura channels and connects with an external element, bridging a gap between the element and the user."
        }
    }

    private fun savePreferences() {
        val prefs = getSharedPreferences("build_prefs", MODE_PRIVATE)
        val editor = prefs.edit()

        editor.putInt("setType", setType)
        editor.putInt("elementType", elementType)

        editor.apply()
    }

    private fun updateSelection() {
        binding.bodyButton.setImageResource(R.drawable.body_unselected)
        binding.mindButton.setImageResource(R.drawable.mind_unselected)
        binding.soulButton.setImageResource(R.drawable.soul_unselected)

        when (setType) {
            0 -> binding.bodyButton.setImageResource(R.drawable.body_selected)
            1 -> binding.mindButton.setImageResource(R.drawable.mind_selected)
            2 -> binding.soulButton.setImageResource(R.drawable.soul_selected)
        }
    }

    private fun updateElement() {
        when (elementType) {
            0 -> binding.elementButton.setImageResource(R.drawable.element_water)
            1 -> binding.elementButton.setImageResource(R.drawable.element_earth)
            2 -> binding.elementButton.setImageResource(R.drawable.element_fire)
            3 -> binding.elementButton.setImageResource(R.drawable.element_air)
        }
    }
}