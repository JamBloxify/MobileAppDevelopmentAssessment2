package com.example.creativecalculator

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class InfoDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        return AlertDialog.Builder(requireContext())
            .setTitle("Creative Calculator by James")

            .setMessage(
                "This app is a creative calculator based on a personal story/lore.\n\n" +

                        "How to use:\n" +
                        "1. Select one of the sets (Outer buttons).\n" +
                        "2. Tap the center button to change element.\n" +
                        "3. Press apply to get a result.\n\n" +
                        "Different combinations give different results.\n\n" +

                        "NOTE: Descriptions are not fully accurate to the specific lore. It is not an objective standard."

            )

            .setPositiveButton("CLOSE") { dialog, _ ->
                dialog.dismiss()
            }

            .create()
    }
}