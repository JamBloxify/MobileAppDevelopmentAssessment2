package com.example.creativecalculator

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.creativecalculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var elementType = 0 // 0-3 (4 types)
    private var setType = 0 // 0-2 (Body, Mind, and Soul Set)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        InfoDialog().show(supportFragmentManager, "info_sheet")

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Body
        binding.bodyButton.setOnClickListener {
            binding.textSet.text = "Body Set: Aura channels throughout the body, generating the element physically."
            setType = 0
            updateSelection()
        }

        // Mind
        binding.mindButton.setOnClickListener {
            binding.textSet.text = "Mind Set: Aura channels to an external object, imbuing it with the element and user's interpretation."
            setType = 1
            updateSelection()
        }

        // Soul
        binding.soulButton.setOnClickListener {
            binding.textSet.text = "Soul Set: Aura channels and connects with an external element, bridging a gap between the element and the user."
            setType = 2
            updateSelection()
        }

        // Info Button
        binding.infoButton.setOnClickListener {
            InfoDialog().show(supportFragmentManager, "info_dialog")
        }

        // Element Button Cycle
        binding.elementButton.setOnClickListener {
            elementType = (elementType + 1) % 4
            updateElement()
        }

        // Apply Button
        binding.applyButton.setOnClickListener {
            updateResult()
        }

        // Initialize UI state
        updateSelection()
        updateElement()
    }

    // Update the selection buttons based on the selected set
    private fun updateSelection() {
        // reset all
        binding.bodyButton.setImageResource(R.drawable.body_unselected)
        binding.mindButton.setImageResource(R.drawable.mind_unselected)
        binding.soulButton.setImageResource(R.drawable.soul_unselected)

        // highlight selected
        when (setType) {
            0 -> binding.bodyButton.setImageResource(R.drawable.body_selected)
            1 -> binding.mindButton.setImageResource(R.drawable.mind_selected)
            2 -> binding.soulButton.setImageResource(R.drawable.soul_selected)
        }
    }

    // Update the element button based on the selected type
    private fun updateElement() {
        when (elementType) {
            0 -> binding.elementButton.setImageResource(R.drawable.element_water)
            1 -> binding.elementButton.setImageResource(R.drawable.element_earth)
            2 -> binding.elementButton.setImageResource(R.drawable.element_fire)
            3 -> binding.elementButton.setImageResource(R.drawable.element_air)
        }
    }

    // Update the result based on the selected set and element
    private fun updateResult() {
        if (setType !in 0..2) {
            binding.textTitle.text = "Select a set first"
            binding.textDesc.text = ""
            return
        }

        when (setType) {
            0 -> { // BODY SET
                when (elementType) {
                    0 -> {
                        binding.image.setImageResource(R.drawable.body_water)
                        binding.textTitle.text = "Liquid State"
                        binding.textDesc.text = "Your body excretes water, allowing for incredibly versatile forms like water tentacles."
                    }
                    1 -> {
                        binding.image.setImageResource(R.drawable.body_earth)
                        binding.textTitle.text = "Walking Fortress"
                        binding.textDesc.text = "Your body develops hard materials, allowing for incredibly offensive-defensive forms like spiky arm shields."
                    }
                    2 -> {
                        binding.image.setImageResource(R.drawable.body_fire)
                        binding.textTitle.text = "Intense Ignition"
                        binding.textDesc.text = "Your body sustains fire, allowing you to coat yourself or shoot flames."
                    }
                    3 -> {
                        binding.image.setImageResource(R.drawable.body_air)
                        binding.textTitle.text = "Flowing Breath"
                        binding.textDesc.text = "Your body circulates air, allowing you to utilize your own breath as powerful gusts or for flight."
                    }
                }
            }

            1 -> { // MIND SET
                when (elementType) {
                    0 -> {
                        binding.image.setImageResource(R.drawable.mind_water)
                        binding.textTitle.text = "Imbued Flow"
                        binding.textDesc.text = "Channel the interpretation of liquids into similar objects, making them viscous or slippery."
                    }
                    1 -> {
                        binding.image.setImageResource(R.drawable.mind_earth)
                        binding.textTitle.text = "Imbued Stability"
                        binding.textDesc.text = "Channel the interpretation of earth into similar objects, making them hard or unstable."
                    }
                    2 -> {
                        binding.image.setImageResource(R.drawable.mind_fire)
                        binding.textTitle.text = "Imbued Sparks"
                        binding.textDesc.text = "Channel the interpretation of fire into similar objects, making them explosive or burning."
                    }
                    3 -> {
                        binding.image.setImageResource(R.drawable.mind_air)
                        binding.textTitle.text = "Imbued Breeze"
                        binding.textDesc.text = "Channel the interpretation of air into similar objects, making them floaty or stormy"
                    }
                }
            }

            2 -> { // SOUL SET
                when (elementType) {
                    0 -> {
                        binding.image.setImageResource(R.drawable.soul_water)
                        binding.textTitle.text = "Remote Geyser"
                        binding.textDesc.text = "Manipulate the properties of water from sources like a puddle or an ocean."
                    }
                    1 -> {
                        binding.image.setImageResource(R.drawable.soul_earth)
                        binding.textTitle.text = "Linked Terraform"
                        binding.textDesc.text = "Manipulate the properties of earth from sources like the ground or a volcano."
                    }
                    2 -> {
                        binding.image.setImageResource(R.drawable.soul_fire)
                        binding.textTitle.text = "Combined Combustion"
                        binding.textDesc.text = "Manipulate the properties of fire from sources like a candle or a wildfire"
                    }
                    3 -> {
                        binding.image.setImageResource(R.drawable.soul_air)
                        binding.textTitle.text = "Mutual Gale"
                        binding.textDesc.text = "Manipulate the properties of air from sources like a breeze or a hurricane."
                    }
                }
            }
        }
    }
}
